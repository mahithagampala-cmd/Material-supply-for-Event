# EventMate - Material Supply for Events

GitHub-ready multi-page website.

## Pages
- index.html - Home
- about.html - About
- materials.html - Material catalogue
- services.html - Services
- events.html - Events
- gallery.html - Gallery
- request.html - Material request form
- contact.html - Contact

## GitHub Pages
Upload all files to the same repository, then enable GitHub Pages from Settings > Pages.
